package org.example.defaultjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DefaultJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}
