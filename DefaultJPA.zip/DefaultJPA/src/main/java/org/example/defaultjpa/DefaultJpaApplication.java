package org.example.defaultjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DefaultJpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(DefaultJpaApplication.class, args);
    }

}
