package org.example.defaultjpa.enums;

public enum SortingDirection {
    ASCENDING, // Less is better
    DESCENDING // More is better
}
