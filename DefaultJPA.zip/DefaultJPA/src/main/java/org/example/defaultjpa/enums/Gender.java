package org.example.defaultjpa.enums;

public enum Gender {
    Male, Female
}
